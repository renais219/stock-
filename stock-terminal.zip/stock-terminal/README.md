# ◈ Stock Terminal

個人股票監控 Dashboard，台股 + 美股混合，支援 GitHub Pages 一鍵部署。

## 功能
- **行情**：台股（TWSE Open API，免費即時）/ 美股（Claude AI Proxy）
- **提醒**：漲破/跌破目標價提醒
- **交易紀錄**：手動輸入，自動計算損益、報酬率、T+2 交割日
- **資產配置**：圓餅圖 + 手動輸入

---

## 部署到 GitHub Pages（5步驟）

### 第一步：Fork 或 clone 這個 repo

```bash
git clone https://github.com/你的帳號/stock-terminal.git
cd stock-terminal
```

### 第二步：設定 API Key（美股行情需要）

在 GitHub repo 頁面：
1. 點 **Settings** → **Secrets and variables** → **Actions**
2. 點 **New repository secret**
3. Name: `VITE_ANTHROPIC_KEY`
4. Value: 你的 `sk-ant-...` key（在 https://console.anthropic.com 申請）

> 台股不需要任何 key，TWSE Open API 完全免費。

### 第三步：開啟 GitHub Pages

1. **Settings** → **Pages**
2. Source 選 **GitHub Actions**

### 第四步：修改 repo 名稱（如果不是 `stock-terminal`）

打開 `vite.config.js`，把第 7 行改成你的 repo 名稱：

```js
base: '/你的repo名稱/',
```

### 第五步：Push 觸發部署

```bash
git add .
git commit -m "deploy"
git push
```

GitHub Actions 會自動 build 並部署，約 1~2 分鐘後可在以下網址存取：

```
https://你的帳號.github.io/stock-terminal/
```

---

## 本機開發

```bash
npm install
cp .env.example .env      # 填入 VITE_ANTHROPIC_KEY
npm run dev               # http://localhost:5173
```

---

## 資料來源

| 市場 | 資料源 | 費用 |
|------|--------|------|
| 台股 | TWSE Open API (`mis.twse.com.tw`) | 免費 |
| 美股 | Claude AI Proxy (Anthropic API) | 需要 API Key |

> **注意**：TWSE Open API 為盤中延遲報價。若需即時五秒報價，可申請 [Fugle API](https://developer.fugle.tw/) 並替換 `fetchTW()` 函式。
