import { useState, useEffect, useRef, useCallback } from "react";

// ═══════════════════════════════════════════════════════════════
// CONFIG  ← 在這裡填入你的 Anthropic API Key
// 或者在 GitHub → Settings → Secrets → Actions 設定環境變數
// ═══════════════════════════════════════════════════════════════
const ANTHROPIC_KEY = import.meta.env.VITE_ANTHROPIC_KEY || "";

// ═══════════════════════════════════════════════════════════════
// DATA CONNECTORS
// Connector 1: TWSE Open API  → 台股 (免費，不需 key)
// Connector 2: Claude AI Proxy → 美股
// ═══════════════════════════════════════════════════════════════
async function fetchTW(symbols) {
  if (!symbols.length) return {};
  try {
    const ids = symbols.map((s) => `tse_${s}.tw`).join("|");
    const url = `https://mis.twse.com.tw/stock/api/getStockInfo.jsp?ex_ch=${encodeURIComponent(ids)}&json=1&delay=0`;
    const res = await fetch(url);
    const data = await res.json();
    const result = {};
    (data.msgArray || []).forEach((d) => {
      const price = parseFloat(d.z) || parseFloat(d.y) || 0;
      const prev = parseFloat(d.y) || 0;
      result[d.c] = {
        name: d.n, price, prev,
        change: price - prev,
        changePct: prev ? ((price - prev) / prev) * 100 : 0,
        high: parseFloat(d.h) || 0,
        low: parseFloat(d.l) || 0,
        volume: parseInt(d.v) || 0,
        currency: "TWD", market: "TW",
      };
    });
    return result;
  } catch { return {}; }
}

async function fetchUS(symbols) {
  if (!symbols.length) return {};
  if (!ANTHROPIC_KEY) {
    console.warn("未設定 VITE_ANTHROPIC_KEY，美股行情無法載入");
    return {};
  }
  const prompt = `You are a financial data agent. Return ONLY valid JSON, no markdown.
Tickers: ${symbols.join(", ")}
Structure per ticker:
{
  "TICKER": {
    "name": "Full Name", "price": 123.45, "prev": 120.00,
    "change": 3.45, "changePct": 2.87,
    "high": 125.00, "low": 119.00, "volume": 45000000,
    "mktCap": 2800000000000, "pe": 28.5,
    "currency": "USD", "market": "US"
  }
}
Return ONLY the JSON object.`;
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_KEY,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1200,
        messages: [{ role: "user", content: prompt }],
      }),
    });
    const data = await res.json();
    const text = data.content?.find((b) => b.type === "text")?.text || "{}";
    return JSON.parse(text.replace(/```json|```/g, "").trim());
  } catch { return {}; }
}

// ═══════════════════════════════════════════════════════════════
// STORAGE  (localStorage — works everywhere)
// ═══════════════════════════════════════════════════════════════
function store(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}
function retrieve(key, fallback) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch { return fallback; }
}

// ═══════════════════════════════════════════════════════════════
// FORMAT UTILS
// ═══════════════════════════════════════════════════════════════
const N = (n, d = 2) =>
  typeof n === "number" && !isNaN(n)
    ? n.toFixed(d).replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    : "--";
const P = (n) => (typeof n === "number" ? `${n >= 0 ? "+" : ""}${N(n)}%` : "--");
const K = (n) => {
  if (!n || isNaN(n)) return "--";
  if (n >= 1e12) return `${(n / 1e12).toFixed(1)}T`;
  if (n >= 1e9)  return `${(n / 1e9).toFixed(1)}B`;
  if (n >= 1e6)  return `${(n / 1e6).toFixed(1)}M`;
  return N(n, 0);
};
const addDays = (d, n) => {
  const dt = new Date(d);
  dt.setDate(dt.getDate() + n);
  return dt.toISOString().slice(0, 10);
};
const daysBetween = (a, b) =>
  !a || !b ? null : Math.round((new Date(b) - new Date(a)) / 86400000);

// ═══════════════════════════════════════════════════════════════
// DESIGN TOKENS
// ═══════════════════════════════════════════════════════════════
const C = {
  bg: "#07090f", surface: "#0c1018", card: "#101520", lift: "#141b26",
  border: "#1c2a3a", borderHi: "#2a4060",
  accent: "#00ff9d", accentDim: "rgba(0,255,157,0.1)", accentMid: "rgba(0,255,157,0.25)",
  gold: "#f5c842", goldDim: "rgba(245,200,66,0.12)",
  red: "#ff3d5a", redDim: "rgba(255,61,90,0.1)",
  blue: "#4db8ff", blueDim: "rgba(77,184,255,0.1)",
  text: "#d4dde8", muted: "#4a6070", faint: "#131e2a",
};
const DONUT_PAL = [C.accent,"#f5c842","#ff3d5a","#4db8ff","#b388ff","#ff9f40","#40f4c8","#f06292"];
const TABS = ["行情 MARKET", "提醒 ALERTS", "交易 TRADES", "配置 PORTFOLIO"];

// ═══════════════════════════════════════════════════════════════
// SUB COMPONENTS
// ═══════════════════════════════════════════════════════════════
function Spark({ data, color, w = 88, h = 36 }) {
  if (!data || data.length < 2) return <svg width={w} height={h} />;
  const mn = Math.min(...data), mx = Math.max(...data), range = mx - mn || 1;
  const pts = data
    .map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - mn) / range) * (h - 4) - 2}`)
    .join(" ");
  const id = `sp${color.replace(/[^a-z0-9]/gi, "")}`;
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.35" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polyline points={`0,${h} ${pts} ${w},${h}`} fill={`url(#${id})`} />
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function Donut({ slices, size = 180 }) {
  const r = 54, cx = 80, cy = 80, circ = 2 * Math.PI * r;
  const total = slices.reduce((s, x) => s + (x.value || 0), 0);
  let off = 0;
  return (
    <svg width={size} height={size} viewBox="0 0 160 160">
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={C.faint} strokeWidth="18" />
      {slices.map((s, i) => {
        const pct = total ? s.value / total : 0;
        const dash = pct * circ;
        const el = (
          <circle key={i} cx={cx} cy={cy} r={r} fill="none" stroke={s.color}
            strokeWidth="18" strokeDasharray={`${dash} ${circ - dash}`}
            strokeDashoffset={-off * circ + circ * 0.25}
            style={{ transition: "stroke-dasharray 0.7s ease" }} />
        );
        off += pct; return el;
      })}
      <circle cx={cx} cy={cy} r={44} fill={C.card} />
    </svg>
  );
}

const Label = ({ t }) => (
  <div style={{ fontSize: 10, color: C.muted, letterSpacing: 1, textTransform: "uppercase", marginBottom: 5 }}>{t}</div>
);
const Field = ({ label, children }) => <div><Label t={label} />{children}</div>;

const Inp = ({ value, onChange, placeholder, type = "text", right = false }) => (
  <input type={type} value={value ?? ""} onChange={(e) => onChange(e.target.value)}
    placeholder={placeholder}
    style={{
      background: C.bg, border: `1px solid ${C.border}`, color: C.text,
      borderRadius: 6, padding: "8px 11px", fontSize: 12, outline: "none",
      width: "100%", fontFamily: "inherit", boxSizing: "border-box",
      textAlign: right ? "right" : "left",
    }}
    onFocus={(e) => (e.target.style.borderColor = C.accentMid)}
    onBlur={(e) => (e.target.style.borderColor = C.border)}
  />
);

const Sel = ({ value, onChange, options }) => (
  <select value={value} onChange={(e) => onChange(e.target.value)}
    style={{
      background: C.bg, border: `1px solid ${C.border}`, color: C.text,
      borderRadius: 6, padding: "8px 11px", fontSize: 12, outline: "none",
      width: "100%", fontFamily: "inherit",
    }}>
    {options.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
  </select>
);

const Btn = ({ label, onClick, variant = "primary", small = false, disabled = false }) => {
  const s = { primary:{bg:C.accent,fg:"#07090f"}, danger:{bg:C.red,fg:"#07090f"}, ghost:{bg:C.lift,fg:C.muted}, gold:{bg:C.gold,fg:"#07090f"} }[variant] || {bg:C.accent,fg:"#07090f"};
  return (
    <button onClick={onClick} disabled={disabled}
      style={{
        background: disabled ? C.faint : s.bg, color: disabled ? C.muted : s.fg,
        border: "none", borderRadius: 6, padding: small ? "5px 12px" : "8px 18px",
        fontSize: small ? 11 : 12, fontWeight: 700, cursor: disabled ? "default" : "pointer",
        fontFamily: "inherit", whiteSpace: "nowrap", letterSpacing: 0.3, opacity: disabled ? 0.4 : 1,
      }}>
      {label}
    </button>
  );
};

const Chip = ({ label, color }) => (
  <span style={{
    background: color + "18", color, border: `1px solid ${color}40`,
    borderRadius: 4, padding: "1px 7px", fontSize: 10, fontWeight: 700, letterSpacing: 0.5,
  }}>{label}</span>
);

const Card = ({ children, style = {}, glow }) => (
  <div style={{
    background: C.card, border: `1px solid ${glow ? C.borderHi : C.border}`,
    borderRadius: 10, padding: 16,
    boxShadow: glow ? `0 0 20px ${C.accent}12` : "none",
    ...style,
  }}>{children}</div>
);

// ═══════════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════════
export default function App() {
  const [twList, setTwList] = useState(() => retrieve("v3_tw", ["2330","2317","2454","00878","0050"]));
  const [usList, setUsList] = useState(() => retrieve("v3_us", ["TSMC","AAPL","NVDA","MSFT"]));
  const [quotes, setQuotes] = useState({});
  const [loading, setLoading] = useState({ tw: false, us: false });
  const [lastUpdate, setLastUpdate] = useState(null);
  const [history, setHistory] = useState({});
  const [addInput, setAddInput] = useState({ ticker: "", market: "TW" });

  const [alerts, setAlerts] = useState(() => retrieve("v3_alerts", []));
  const [alertForm, setAlertForm] = useState({ ticker: "", type: "above", target: "" });
  const triggered = useRef(new Set());

  const blankTrade = { ticker:"",name:"",market:"TW",action:"買",qty:"",buyPrice:"",buyDate:"",sellPrice:"",sellDate:"",fee:"",tax:"",note:"" };
  const [trades, setTrades] = useState(() => retrieve("v3_trades", []));
  const [showTF, setShowTF] = useState(false);
  const [editTID, setEditTID] = useState(null);
  const [tf, setTf] = useState(blankTrade);

  const blankPF = { name:"", value:"", color: DONUT_PAL[0], note:"" };
  const [portfolio, setPortfolio] = useState(() => retrieve("v3_portfolio", []));
  const [showPF, setShowPF] = useState(false);
  const [editPFi, setEditPFi] = useState(null);
  const [pf, setPf] = useState(blankPF);

  const [tab, setTab] = useState(0);

  // ── persist ──
  useEffect(() => { store("v3_tw", twList); }, [twList]);
  useEffect(() => { store("v3_us", usList); }, [usList]);
  useEffect(() => { store("v3_alerts", alerts); }, [alerts]);
  useEffect(() => { store("v3_trades", trades); }, [trades]);
  useEffect(() => { store("v3_portfolio", portfolio); }, [portfolio]);

  // ── fetch ──
  const refreshTW = useCallback(async () => {
    if (!twList.length) return;
    setLoading((p) => ({ ...p, tw: true }));
    const data = await fetchTW(twList);
    setQuotes((p) => {
      const next = { ...p };
      Object.entries(data).forEach(([k, v]) => {
        next[k] = v;
        setHistory((h) => ({ ...h, [k]: [...(h[k] || []).slice(-29), v.price] }));
      });
      return next;
    });
    setLastUpdate(new Date());
    setLoading((p) => ({ ...p, tw: false }));
  }, [twList]);

  const refreshUS = useCallback(async () => {
    if (!usList.length) return;
    setLoading((p) => ({ ...p, us: true }));
    const data = await fetchUS(usList);
    setQuotes((p) => {
      const next = { ...p };
      Object.entries(data).forEach(([k, v]) => {
        next[k] = v;
        setHistory((h) => ({ ...h, [k]: [...(h[k] || []).slice(-29), v.price] }));
      });
      return next;
    });
    setLastUpdate(new Date());
    setLoading((p) => ({ ...p, us: false }));
  }, [usList]);

  useEffect(() => { refreshTW(); }, [twList]);
  useEffect(() => { refreshUS(); }, [usList]);

  // ── alert check ──
  useEffect(() => {
    if (!Object.keys(quotes).length) return;
    setAlerts((prev) =>
      prev.map((a) => {
        const q = quotes[a.ticker];
        if (!q) return a;
        const hit = a.type === "above" ? q.price >= a.target : q.price <= a.target;
        if (hit && !triggered.current.has(a.id)) {
          triggered.current.add(a.id);
          return { ...a, triggered: true };
        }
        return a;
      })
    );
  }, [quotes]);

  // ── trade calc ──
  function calcTrade(t) {
    const curr = t.sellPrice ? +t.sellPrice : (quotes[t.ticker]?.price ?? null);
    if (!curr || !t.buyPrice || !t.qty) return null;
    const cost = +t.buyPrice * +t.qty;
    const pnl  = curr * +t.qty - cost - +(t.fee || 0) - +(t.tax || 0);
    return { pnl, pct: cost ? (pnl / cost) * 100 : 0, curr, days: daysBetween(t.buyDate, t.sellDate || null) };
  }

  function saveTrade() {
    if (!tf.ticker || !tf.qty || !tf.buyPrice) return;
    const entry = {
      ...tf, id: editTID || Date.now(),
      qty: +tf.qty, buyPrice: +tf.buyPrice,
      sellPrice: tf.sellPrice ? +tf.sellPrice : null,
      settlement: tf.sellDate ? addDays(tf.sellDate, 2) : null,
      status: tf.sellPrice ? "已交割" : "持有中",
    };
    setTrades((p) => editTID ? p.map((x) => x.id === editTID ? entry : x) : [...p, entry]);
    setShowTF(false); setEditTID(null); setTf(blankTrade);
  }

  function editTrade(t) {
    setTf({ ...t, qty: String(t.qty), buyPrice: String(t.buyPrice),
      sellPrice: t.sellPrice ? String(t.sellPrice) : "",
      fee: t.fee || "", tax: t.tax || "", note: t.note || "" });
    setEditTID(t.id); setShowTF(true);
  }

  function savePF() {
    if (!pf.name || !pf.value) return;
    const entry = { ...pf, value: +pf.value };
    setPortfolio((p) => editPFi !== null ? p.map((x, i) => i === editPFi ? entry : x) : [...p, entry]);
    setShowPF(false); setEditPFi(null); setPf(blankPF);
  }

  const totalPnl    = trades.reduce((s, t) => { const r = calcTrade(t); return s + (r?.pnl || 0); }, 0);
  const totalAssets = portfolio.reduce((s, p) => s + (p.value || 0), 0);

  // ── quote card ──
  function QuoteCard({ sym }) {
    const q = quotes[sym];
    const up = q ? q.change >= 0 : null;
    const col = up === null ? C.muted : up ? C.accent : C.red;
    const isTW = q?.market === "TW" || twList.includes(sym);
    return (
      <div style={{
        background: C.card, border: `1px solid ${C.border}`,
        borderLeft: `3px solid ${q ? col : C.border}`,
        borderRadius: 10, padding: 14,
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span style={{ fontWeight: 800, fontSize: 14 }}>{sym}</span>
              <Chip label={isTW ? "台股" : "美股"} color={isTW ? C.accent : C.blue} />
            </div>
            <div style={{ fontSize: 11, color: C.muted, marginTop: 3 }}>{q?.name || "載入中…"}</div>
          </div>
          <div style={{ textAlign: "right" }}>
            {q ? (
              <>
                <div style={{ fontSize: 22, fontWeight: 800, color: col, lineHeight: 1 }}>{N(q.price)}</div>
                <div style={{ fontSize: 11, color: col, marginTop: 2, fontWeight: 600 }}>
                  {up ? "▲" : "▼"} {N(Math.abs(q.change))} ({P(q.changePct)})
                </div>
              </>
            ) : <div style={{ fontSize: 12, color: C.muted }}>--</div>}
          </div>
        </div>
        {q && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 4, marginTop: 10, fontSize: 10, color: C.muted }}>
            <div>高 <b style={{ color: C.text }}>{N(q.high)}</b></div>
            <div>低 <b style={{ color: C.text }}>{N(q.low)}</b></div>
            <div>{q.market === "US" ? "市值" : "量"} <b style={{ color: C.text }}>{q.market === "US" ? K(q.mktCap) : K(q.volume)}</b></div>
          </div>
        )}
        <div style={{ marginTop: 10 }}>
          <Spark data={history[sym] || []} color={q ? col : C.muted} />
        </div>
        <div style={{ marginTop: 8, textAlign: "right" }}>
          <button onClick={() => isTW ? setTwList((p) => p.filter((x) => x !== sym)) : setUsList((p) => p.filter((x) => x !== sym))}
            style={{ background:"none",border:"none",color:C.muted,cursor:"pointer",fontSize:10,fontFamily:"inherit" }}>
            ✕ 移除
          </button>
        </div>
      </div>
    );
  }

  // ══════════════════════════════════════════════════════════════
  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, fontFamily: "'JetBrains Mono','Fira Code','SF Mono',monospace", paddingBottom: 80 }}>

      {/* HEADER */}
      <div style={{ background: C.surface, borderBottom: `1px solid ${C.border}`, padding: "14px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 300 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div>
            <div style={{ fontSize: 15, fontWeight: 900, letterSpacing: 4, color: C.accent }}>◈ STOCK TERMINAL</div>
            <div style={{ fontSize: 9, color: C.muted, marginTop: 1, letterSpacing: 1 }}>
              TW: TWSE OPEN API · US: CLAUDE AI PROXY · {lastUpdate ? lastUpdate.toLocaleTimeString("zh-TW") : "未載入"}
            </div>
          </div>
          <div style={{ display: "flex", gap: 6 }}>
            <Btn label={loading.tw ? "⟳ 台股…" : "↻ 台股"} onClick={refreshTW} disabled={loading.tw} small />
            <Btn label={loading.us ? "⟳ 美股…" : "↻ 美股"} onClick={refreshUS} disabled={loading.us} small variant="ghost" />
          </div>
        </div>
        <div style={{ display: "flex", gap: 24 }}>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 9, color: C.muted, letterSpacing: 1 }}>總損益</div>
            <div style={{ fontSize: 20, fontWeight: 900, color: totalPnl >= 0 ? C.accent : C.red }}>{totalPnl >= 0 ? "+" : ""}{N(totalPnl)}</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 9, color: C.muted, letterSpacing: 1 }}>總資產</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: C.blue }}>{N(totalAssets)}</div>
          </div>
        </div>
      </div>

      {/* TABS */}
      <div style={{ display: "flex", background: C.surface, borderBottom: `1px solid ${C.border}`, padding: "0 24px" }}>
        {TABS.map((t, i) => (
          <button key={i} onClick={() => setTab(i)} style={{
            background: "none", border: "none",
            color: tab === i ? C.accent : C.muted,
            borderBottom: tab === i ? `2px solid ${C.accent}` : "2px solid transparent",
            padding: "10px 18px", fontSize: 11, fontWeight: tab === i ? 700 : 400,
            cursor: "pointer", fontFamily: "inherit", letterSpacing: 1.5, marginBottom: -1,
          }}>{t}</button>
        ))}
      </div>

      <div style={{ padding: "20px 24px", maxWidth: 1200, margin: "0 auto" }}>

        {/* ── MARKET ── */}
        {tab === 0 && (
          <div>
            {!ANTHROPIC_KEY && (
              <div style={{ background: C.goldDim, border: `1px solid ${C.gold}`, borderRadius: 8, padding: "10px 16px", marginBottom: 16, fontSize: 12, color: C.gold }}>
                ⚠ 尚未設定 VITE_ANTHROPIC_KEY，美股行情將無法載入。請在 <code>.env</code> 檔案加入 <code>VITE_ANTHROPIC_KEY=sk-ant-...</code>
              </div>
            )}
            <Card style={{ marginBottom: 18 }}>
              <div style={{ display: "flex", gap: 10, alignItems: "flex-end", flexWrap: "wrap" }}>
                <Field label="新增股票代號">
                  <Inp value={addInput.ticker} onChange={(v) => setAddInput((p) => ({ ...p, ticker: v.toUpperCase() }))} placeholder="e.g. 2412 or META" />
                </Field>
                <Field label="市場">
                  <Sel value={addInput.market} onChange={(v) => setAddInput((p) => ({ ...p, market: v }))}
                    options={[{ v: "TW", l: "台股 (TWSE)" }, { v: "US", l: "美股 (US)" }]} />
                </Field>
                <Btn label="加入觀察" onClick={() => {
                  const t = addInput.ticker.trim();
                  if (!t) return;
                  if (addInput.market === "TW") setTwList((p) => (p.includes(t) ? p : [...p, t]));
                  else setUsList((p) => (p.includes(t) ? p : [...p, t]));
                  setAddInput((p) => ({ ...p, ticker: "" }));
                }} />
              </div>
            </Card>

            {twList.length > 0 && <>
              <div style={{ fontSize: 10, color: C.muted, letterSpacing: 2, marginBottom: 10 }}>
                ── 台股 TAIWAN ({twList.length}) <span style={{ color: C.accent }}>{loading.tw ? "⟳ 更新中" : "● TWSE OPEN API"}</span>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(260px,1fr))", gap: 10, marginBottom: 20 }}>
                {twList.map((sym) => <QuoteCard key={sym} sym={sym} />)}
              </div>
            </>}

            {usList.length > 0 && <>
              <div style={{ fontSize: 10, color: C.muted, letterSpacing: 2, marginBottom: 10 }}>
                ── 美股 US ({usList.length}) <span style={{ color: C.blue }}>{loading.us ? "⟳ 更新中" : "● CLAUDE AI PROXY"}</span>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(260px,1fr))", gap: 10 }}>
                {usList.map((sym) => <QuoteCard key={sym} sym={sym} />)}
              </div>
            </>}
          </div>
        )}

        {/* ── ALERTS ── */}
        {tab === 1 && (
          <div style={{ maxWidth: 680 }}>
            <Card style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 11, color: C.accent, letterSpacing: 2, marginBottom: 14 }}>NEW ALERT</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr auto", gap: 10, alignItems: "end" }}>
                <Field label="股票代號"><Inp value={alertForm.ticker} onChange={(v) => setAlertForm((p) => ({ ...p, ticker: v.toUpperCase() }))} placeholder="e.g. 2330" /></Field>
                <Field label="觸發條件">
                  <Sel value={alertForm.type} onChange={(v) => setAlertForm((p) => ({ ...p, type: v }))}
                    options={[{ v: "above", l: "漲破 ▲" }, { v: "below", l: "跌破 ▼" }]} />
                </Field>
                <Field label="目標價"><Inp value={alertForm.target} onChange={(v) => setAlertForm((p) => ({ ...p, target: v }))} placeholder="e.g. 1000" type="number" right /></Field>
                <Btn label="設定" onClick={() => {
                  if (!alertForm.ticker || !alertForm.target) return;
                  setAlerts((p) => [...p, { id: Date.now(), ...alertForm, target: +alertForm.target, triggered: false }]);
                  setAlertForm({ ticker: "", type: "above", target: "" });
                }} />
              </div>
            </Card>
            <div style={{ fontSize: 10, color: C.muted, letterSpacing: 2, marginBottom: 12 }}>ACTIVE ALERTS ({alerts.length})</div>
            {alerts.length === 0 && <div style={{ color: C.muted, textAlign: "center", padding: 60 }}>尚無提醒</div>}
            {alerts.map((a) => {
              const curr = quotes[a.ticker]?.price;
              const dist = curr ? ((curr - a.target) / a.target * 100) : null;
              return (
                <div key={a.id} style={{ background: a.triggered ? C.goldDim : C.card, border: `1px solid ${a.triggered ? C.gold : C.border}`, borderRadius: 10, padding: "14px 18px", marginBottom: 10, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
                    <div style={{ fontSize: 22 }}>{a.triggered ? "🔔" : "🔕"}</div>
                    <div>
                      <div style={{ fontWeight: 800 }}>{a.ticker}
                        <span style={{ color: C.muted, fontWeight: 400, fontSize: 11, marginLeft: 10 }}>
                          {a.type === "above" ? "漲破" : "跌破"} {N(a.target)}
                        </span>
                      </div>
                      <div style={{ fontSize: 11, color: C.muted, marginTop: 3 }}>
                        現價 {curr ? N(curr) : "未載入"}
                        {dist !== null && <span style={{ marginLeft: 8, color: Math.abs(dist) < 2 ? C.gold : C.muted }}>距目標 {dist >= 0 ? "+" : ""}{dist.toFixed(1)}%</span>}
                        {a.triggered && <span style={{ color: C.gold, fontWeight: 700, marginLeft: 10 }}>⚠ 已觸發！</span>}
                      </div>
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    {a.triggered && <Btn label="重設" variant="gold" small onClick={() => { triggered.current.delete(a.id); setAlerts((p) => p.map((x) => x.id === a.id ? { ...x, triggered: false } : x)); }} />}
                    <Btn label="刪除" variant="ghost" small onClick={() => setAlerts((p) => p.filter((x) => x.id !== a.id))} />
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ── TRADES ── */}
        {tab === 2 && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ fontSize: 10, color: C.muted, letterSpacing: 2 }}>TRADE LOG</div>
              <Btn label={showTF ? "✕ 收起" : "+ 新增交易"} onClick={() => { setShowTF((p) => !p); setEditTID(null); setTf(blankTrade); }} />
            </div>
            {showTF && (
              <Card style={{ marginBottom: 20 }} glow>
                <div style={{ fontSize: 11, color: C.accent, letterSpacing: 2, marginBottom: 16 }}>{editTID ? "EDIT TRADE" : "NEW TRADE"}</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12 }}>
                  <Field label="股票代號"><Inp value={tf.ticker} onChange={(v) => setTf((p) => ({ ...p, ticker: v.toUpperCase() }))} placeholder="e.g. 2330" /></Field>
                  <Field label="股票名稱"><Inp value={tf.name} onChange={(v) => setTf((p) => ({ ...p, name: v }))} placeholder="e.g. 台積電" /></Field>
                  <Field label="市場"><Sel value={tf.market} onChange={(v) => setTf((p) => ({ ...p, market: v }))} options={[{ v:"TW",l:"台股" }, { v:"US",l:"美股" }]} /></Field>
                  <Field label="買/賣"><Sel value={tf.action} onChange={(v) => setTf((p) => ({ ...p, action: v }))} options={[{ v:"買",l:"買進" }, { v:"賣",l:"賣出" }]} /></Field>
                  <Field label="股數/張數"><Inp value={tf.qty} onChange={(v) => setTf((p) => ({ ...p, qty: v }))} placeholder="1000" type="number" right /></Field>
                  <Field label="買入均價"><Inp value={tf.buyPrice} onChange={(v) => setTf((p) => ({ ...p, buyPrice: v }))} placeholder="890" type="number" right /></Field>
                  <Field label="買入日期"><Inp value={tf.buyDate} onChange={(v) => setTf((p) => ({ ...p, buyDate: v }))} type="date" /></Field>
                  <Field label="手續費"><Inp value={tf.fee} onChange={(v) => setTf((p) => ({ ...p, fee: v }))} placeholder="149" type="number" right /></Field>
                  <Field label="賣出價（選填）"><Inp value={tf.sellPrice} onChange={(v) => setTf((p) => ({ ...p, sellPrice: v }))} placeholder="持有中留空" type="number" right /></Field>
                  <Field label="賣出日期"><Inp value={tf.sellDate} onChange={(v) => setTf((p) => ({ ...p, sellDate: v }))} type="date" /></Field>
                  <Field label="交易稅"><Inp value={tf.tax} onChange={(v) => setTf((p) => ({ ...p, tax: v }))} placeholder="265" type="number" right /></Field>
                  <Field label="備註"><Inp value={tf.note} onChange={(v) => setTf((p) => ({ ...p, note: v }))} placeholder="自由填寫" /></Field>
                </div>
                <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 16 }}>
                  <Btn label="儲存" onClick={saveTrade} />
                  <Btn label="取消" variant="ghost" onClick={() => { setShowTF(false); setEditTID(null); }} />
                </div>
              </Card>
            )}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10, marginBottom: 18 }}>
              {[
                { l:"總筆數", v:trades.length, c:C.text },
                { l:"持有中", v:trades.filter((t)=>t.status==="持有中").length, c:C.accent },
                { l:"已交割", v:trades.filter((t)=>t.status==="已交割").length, c:C.muted },
                { l:"總損益（含費）", v:`${totalPnl>=0?"+":""}${N(totalPnl)}`, c:totalPnl>=0?C.accent:C.red },
              ].map((s) => (
                <Card key={s.l} style={{ textAlign:"center" }}>
                  <div style={{ fontSize:9, color:C.muted, letterSpacing:1 }}>{s.l}</div>
                  <div style={{ fontSize:20, fontWeight:900, color:s.c, marginTop:6 }}>{s.v}</div>
                </Card>
              ))}
            </div>
            {trades.length === 0
              ? <div style={{ color:C.muted, textAlign:"center", padding:80 }}>尚無交易紀錄，點「新增交易」開始記錄</div>
              : (
                <div style={{ overflowX:"auto" }}>
                  <table style={{ width:"100%", borderCollapse:"separate", borderSpacing:"0 6px", fontSize:11 }}>
                    <thead>
                      <tr style={{ color:C.muted, fontSize:9, letterSpacing:1 }}>
                        {["代號/名稱","市場","方向","股數","買入價","現價","損益","報酬率","持有天數","買入日","交割日","狀態",""].map((h) => (
                          <th key={h} style={{ textAlign:"left", padding:"4px 10px", fontWeight:400, whiteSpace:"nowrap" }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {trades.map((t) => {
                        const r = calcTrade(t);
                        const col = r ? (r.pnl >= 0 ? C.accent : C.red) : C.muted;
                        return (
                          <tr key={t.id} style={{ background:C.card }}>
                            <td style={{ padding:"11px 10px", borderRadius:"8px 0 0 8px" }}>
                              <div style={{ fontWeight:800 }}>{t.ticker}</div>
                              <div style={{ color:C.muted, fontSize:9 }}>{t.name}</div>
                            </td>
                            <td style={{ padding:"11px 10px" }}><Chip label={t.market==="TW"?"台":"美"} color={t.market==="TW"?C.accent:C.blue} /></td>
                            <td style={{ padding:"11px 10px" }}><Chip label={t.action} color={t.action==="買"?C.accent:C.red} /></td>
                            <td style={{ padding:"11px 10px" }}>{t.qty}</td>
                            <td style={{ padding:"11px 10px" }}>{N(t.buyPrice)}</td>
                            <td style={{ padding:"11px 10px", color:col }}>{r ? N(r.curr) : "--"}</td>
                            <td style={{ padding:"11px 10px", fontWeight:700, color:col }}>{r ? `${r.pnl>=0?"+":""}${N(r.pnl)}` : "--"}</td>
                            <td style={{ padding:"11px 10px", fontWeight:700, color:col }}>{r ? P(r.pct) : "--"}</td>
                            <td style={{ padding:"11px 10px", color:C.muted }}>{r?.days ?? "--"}</td>
                            <td style={{ padding:"11px 10px", color:C.muted, whiteSpace:"nowrap" }}>{t.buyDate||"--"}</td>
                            <td style={{ padding:"11px 10px", color:C.muted, whiteSpace:"nowrap" }}>{t.settlement||"--"}</td>
                            <td style={{ padding:"11px 10px" }}><Chip label={t.status} color={t.status==="持有中"?C.accent:C.muted} /></td>
                            <td style={{ padding:"11px 10px", borderRadius:"0 8px 8px 0", whiteSpace:"nowrap" }}>
                              <button onClick={() => editTrade(t)} style={{ background:"none",border:"none",color:C.blue,cursor:"pointer",fontSize:10,fontFamily:"inherit",marginRight:8 }}>編輯</button>
                              <button onClick={() => setTrades((p) => p.filter((x) => x.id !== t.id))} style={{ background:"none",border:"none",color:C.red,cursor:"pointer",fontSize:10,fontFamily:"inherit" }}>刪除</button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
          </div>
        )}

        {/* ── PORTFOLIO ── */}
        {tab === 3 && (
          <div>
            <div style={{ display:"flex", gap:28, alignItems:"flex-start", flexWrap:"wrap", marginBottom:24 }}>
              <div style={{ minWidth:220, textAlign:"center" }}>
                <Donut slices={portfolio.length ? portfolio : [{ name:"無", value:1, color:C.faint }]} size={200} />
                <div style={{ marginTop:10 }}>
                  <div style={{ fontSize:9, color:C.muted, letterSpacing:1 }}>TOTAL ASSETS</div>
                  <div style={{ fontSize:26, fontWeight:900, color:C.accent }}>{N(totalAssets)}</div>
                </div>
              </div>
              <div style={{ flex:1, minWidth:300 }}>
                {portfolio.length === 0 && <div style={{ color:C.muted, textAlign:"center", padding:60 }}>點「新增類別」開始設定資產配置</div>}
                {portfolio.map((p, i) => {
                  const pct = totalAssets ? (p.value / totalAssets * 100) : 0;
                  return (
                    <div key={i} style={{ background:C.card, border:`1px solid ${C.border}`, borderLeft:`3px solid ${p.color}`, borderRadius:10, padding:"14px 18px", marginBottom:10 }}>
                      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
                        <div>
                          <span style={{ fontWeight:800 }}>{p.name}</span>
                          {p.note && <span style={{ fontSize:10, color:C.muted, marginLeft:8 }}>— {p.note}</span>}
                        </div>
                        <div style={{ textAlign:"right" }}>
                          <div style={{ fontWeight:800, fontSize:16 }}>{N(p.value)}</div>
                          <div style={{ fontSize:11, color:C.muted }}>{N(pct, 1)}%</div>
                        </div>
                      </div>
                      <div style={{ background:C.faint, borderRadius:3, height:4 }}>
                        <div style={{ width:`${pct}%`, background:p.color, height:"100%", borderRadius:3, transition:"width 0.6s ease" }} />
                      </div>
                      <div style={{ display:"flex", gap:8, justifyContent:"flex-end", marginTop:10 }}>
                        <button onClick={() => { setPf({ ...p, value:String(p.value) }); setEditPFi(i); setShowPF(true); }} style={{ background:"none",border:"none",color:C.blue,cursor:"pointer",fontSize:10,fontFamily:"inherit" }}>編輯</button>
                        <button onClick={() => setPortfolio((prev) => prev.filter((_,j) => j !== i))} style={{ background:"none",border:"none",color:C.red,cursor:"pointer",fontSize:10,fontFamily:"inherit" }}>刪除</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            <div style={{ display:"flex", justifyContent:"flex-end", marginBottom:12 }}>
              <Btn label={showPF ? "✕ 收起" : "+ 新增類別"} onClick={() => { setShowPF((p) => !p); setEditPFi(null); setPf({ ...blankPF, color:DONUT_PAL[portfolio.length % DONUT_PAL.length] }); }} />
            </div>
            {showPF && (
              <Card glow>
                <div style={{ fontSize:11, color:C.accent, letterSpacing:2, marginBottom:14 }}>{editPFi !== null ? "EDIT ALLOCATION" : "NEW ALLOCATION"}</div>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 80px 1fr auto", gap:12, alignItems:"end" }}>
                  <Field label="類別名稱"><Inp value={pf.name} onChange={(v) => setPf((p) => ({ ...p, name:v }))} placeholder="e.g. 台股, 現金, ETF" /></Field>
                  <Field label="金額"><Inp value={pf.value} onChange={(v) => setPf((p) => ({ ...p, value:v }))} placeholder="e.g. 500000" type="number" right /></Field>
                  <Field label="顏色">
                    <input type="color" value={pf.color} onChange={(e) => setPf((p) => ({ ...p, color:e.target.value }))}
                      style={{ width:"100%", height:37, border:`1px solid ${C.border}`, borderRadius:6, cursor:"pointer", background:C.bg }} />
                  </Field>
                  <Field label="備註"><Inp value={pf.note} onChange={(v) => setPf((p) => ({ ...p, note:v }))} placeholder="e.g. 個股+ETF" /></Field>
                  <Btn label="儲存" onClick={savePF} />
                </div>
              </Card>
            )}
            {portfolio.length > 0 && (
              <div style={{ marginTop:24 }}>
                <div style={{ fontSize:10, color:C.muted, letterSpacing:2, marginBottom:12 }}>QUICK ADJUST</div>
                <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))", gap:10 }}>
                  {portfolio.map((p, i) => (
                    <div key={i} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:8, padding:"11px 14px" }}>
                      <div style={{ display:"flex", gap:6, alignItems:"center", marginBottom:7 }}>
                        <div style={{ width:8, height:8, borderRadius:"50%", background:p.color, flexShrink:0 }} />
                        <div style={{ fontSize:12, fontWeight:700 }}>{p.name}</div>
                      </div>
                      <input type="number" value={p.value} onChange={(e) => setPortfolio((prev) => prev.map((x,j) => j===i ? { ...x, value:+e.target.value } : x))}
                        style={{ background:C.bg, border:`1px solid ${C.border}`, color:C.text, borderRadius:6, padding:"7px 10px", fontSize:13, width:"100%", outline:"none", textAlign:"right", fontFamily:"inherit", boxSizing:"border-box" }} />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
